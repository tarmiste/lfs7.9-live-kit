
	      //Resource strings for localization
	      var localeresource = new Object;
	      localeresource["search_no_results"]="Your search returned no results.";
            